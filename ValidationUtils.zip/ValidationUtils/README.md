# ValidationUtils
Validate your Email Id or Phone Number